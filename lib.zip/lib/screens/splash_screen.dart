// ─────────────────────────────────────────────────────────────────────────────
//  splash_screen.dart  (updated)
//  • Calls LocationService.init() while the animation plays
//  • Coordinates are ready in LocationService.lt / .ln by the time
//    the user reaches the Login screen and taps "GET OTP"
// ─────────────────────────────────────────────────────────────────────────────

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'location_service.dart';   // ← NEW
import 'auth_screen.dart';        // file that contains LoginScreen, OtpScreen, etc.

// ══════════════════════════════════════════════════════════════════════════════
//  SPLASH SCREEN
// ══════════════════════════════════════════════════════════════════════════════
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {

  late AnimationController _ringCtrl;
  late AnimationController _fadeCtrl;
  late AnimationController _leafCtrl;
  late Animation<double>   _ringScale;
  late Animation<double>   _logoFade;
  late Animation<double>   _logoSlide;
  late Animation<double>   _taglineFade;
  late Animation<double>   _leafRot;

  // ── Location fetch state ───────────────────────────────────────────────────
  String _locationStatus = 'Fetching location…';

  @override
  void initState() {
    super.initState();

    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));

    // ── Animation controllers ──────────────────────────────────────────────
    _ringCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1400));
    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800));
    _leafCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _ringScale = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _ringCtrl, curve: Curves.elasticOut));
    _logoFade  = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _fadeCtrl,
            curve: const Interval(0.0, 0.5, curve: Curves.easeOut)));
    _logoSlide = Tween<double>(begin: 40.0, end: 0.0).animate(
        CurvedAnimation(parent: _fadeCtrl,
            curve: const Interval(0.0, 0.6, curve: Curves.easeOut)));
    _taglineFade = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _fadeCtrl,
            curve: const Interval(0.5, 1.0, curve: Curves.easeIn)));
    _leafRot = Tween<double>(begin: 0.0, end: 2 * math.pi).animate(
        CurvedAnimation(parent: _leafCtrl, curve: Curves.linear));

    Future.delayed(const Duration(milliseconds: 200), () {
      _ringCtrl.forward();
      _fadeCtrl.forward();
    });

    // ── Fetch location in parallel with the splash animation ────────────────
    _initLocation();

    // ── Navigate after 3.2 s (location fetch is fire-and-forget) ────────────
    Future.delayed(const Duration(milliseconds: 3200), _navigate);
  }

  // ── Location init ──────────────────────────────────────────────────────────
  Future<void> _initLocation() async {
    await LocationService.init();
    if (!mounted) return;
    setState(() {
      _locationStatus = LocationService.fetched
          ? 'Location: ${LocationService.lt}, ${LocationService.ln}'
          : 'Location unavailable';
    });
  }

  // ── Navigate to Login ──────────────────────────────────────────────────────
  void _navigate() {
    if (!mounted) return;
    Navigator.pushReplacement(context, _fadeRoute(const LoginScreen()));
  }

  @override
  void dispose() {
    _ringCtrl.dispose();
    _fadeCtrl.dispose();
    _leafCtrl.dispose();
    super.dispose();
  }

  // ── Build ──────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: _C.splashBg,
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: _MeshPainter())),

          // Floating leaves
          ...List.generate(6, (i) => _FloatingLeaf(index: i, rot: _leafRot)),

          // Wave at bottom
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: ClipPath(
              clipper: _WaveClipper(),
              child: Container(
                height: size.height * 0.28,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF1B8A3E), Color(0xFF0D5C28)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ),
            ),
          ),

          // Ring animation
          Center(
            child: AnimatedBuilder(
              animation: _ringScale,
              builder: (_, __) => Stack(
                alignment: Alignment.center,
                children: [
                  Transform.scale(
                    scale: _ringScale.value,
                    child: Container(
                      width: 200, height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: _C.accent.withOpacity(0.15), width: 40),
                      ),
                    ),
                  ),
                  Transform.scale(
                    scale: _ringScale.value * 0.82,
                    child: Container(
                      width: 200, height: 200,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: _C.accent.withOpacity(0.25), width: 20),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Logo + tagline
          Center(
            child: AnimatedBuilder(
              animation: _fadeCtrl,
              builder: (_, __) => Opacity(
                opacity: _logoFade.value,
                child: Transform.translate(
                  offset: Offset(0, _logoSlide.value),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // App icon
                      Container(
                        width: 110, height: 110,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF4CAF50), Color(0xFF1B8A3E)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(28),
                          boxShadow: [
                            BoxShadow(
                              color: _C.accent.withOpacity(0.5),
                              blurRadius: 40,
                              spreadRadius: 4,
                              offset: const Offset(0, 12),
                            ),
                          ],
                        ),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            const Icon(Icons.eco_rounded,
                                color: Colors.white, size: 54),
                            Positioned(
                              top: 14, right: 14,
                              child: Container(
                                width: 10, height: 10,
                                decoration: const BoxDecoration(
                                  color: Colors.white,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 22),

                      // App name
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: 'Agro',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 42,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -1,
                              ),
                            ),
                            TextSpan(
                              text: 'Soft',
                              style: TextStyle(
                                color: Color(0xFF4CAF50),
                                fontSize: 42,
                                fontWeight: FontWeight.w900,
                                letterSpacing: -1,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),

                      // Tagline
                      AnimatedBuilder(
                        animation: _taglineFade,
                        builder: (_, __) => Opacity(
                          opacity: _taglineFade.value,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                  width: 28, height: 1.5,
                                  color: _C.accentLt.withOpacity(0.6)),
                              const SizedBox(width: 10),
                              Text(
                                'Smart Farming Solutions',
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.7),
                                  fontSize: 13,
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 1.4,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Container(
                                  width: 28, height: 1.5,
                                  color: _C.accentLt.withOpacity(0.6)),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 16),

                      // ── NEW: Location chip ───────────────────────────────
                      AnimatedBuilder(
                        animation: _taglineFade,
                        builder: (_, __) => Opacity(
                          opacity: _taglineFade.value,
                          child: _LocationChip(status: _locationStatus),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Bottom loading dots + version
          Positioned(
            bottom: 36, left: 0, right: 0,
            child: AnimatedBuilder(
              animation: _taglineFade,
              builder: (_, __) => Opacity(
                opacity: _taglineFade.value,
                child: Column(
                  children: [
                    const _LoadingDots(),
                    const SizedBox(height: 10),
                    Text(
                      'v1.0.0',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.35),
                        fontSize: 11,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Location chip widget ──────────────────────────────────────────────────────
class _LocationChip extends StatelessWidget {
  final String status;
  const _LocationChip({required this.status});

  @override
  Widget build(BuildContext context) {
    final bool ok = status.startsWith('Location:');
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: ok
            ? const Color(0xFF4CAF50).withOpacity(0.18)
            : Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: ok
              ? const Color(0xFF4CAF50).withOpacity(0.4)
              : Colors.white.withOpacity(0.15),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            ok ? Icons.location_on_rounded : Icons.location_searching_rounded,
            color: ok
                ? const Color(0xFF4CAF50)
                : Colors.white.withOpacity(0.5),
            size: 13,
          ),
          const SizedBox(width: 6),
          Text(
            status,
            style: TextStyle(
              color: ok
                  ? Colors.white.withOpacity(0.85)
                  : Colors.white.withOpacity(0.45),
              fontSize: 10,
              letterSpacing: 0.4,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  COLOUR PALETTE  (same as original — keep in a shared constants file
//  if you prefer to avoid duplication across screens)
// ─────────────────────────────────────────────────────────────────────────────
class _C {
  static const bg         = Color(0xFFF2F7F2);
  static const surface    = Colors.white;
  static const primary    = Color(0xFF1B8A3E);
  static const primaryLt  = Color(0xFFE6F4EC);
  static const accent     = Color(0xFF4CAF50);
  static const accentLt   = Color(0xFFA5D6A7);
  static const textMid    = Color(0xFF5A7260);
  static const splashBg   = Color(0xFF0D4A1F);
}

// ─────────────────────────────────────────────────────────────────────────────
//  HELPERS  (loading dots, floating leaf, painters, route helpers)
// ─────────────────────────────────────────────────────────────────────────────
class _LoadingDots extends StatefulWidget {
  const _LoadingDots();
  @override
  State<_LoadingDots> createState() => _LoadingDotsState();
}
class _LoadingDotsState extends State<_LoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat();
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: _ctrl,
    builder: (_, __) => Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(3, (i) {
        final t = (_ctrl.value - i * 0.15).clamp(0.0, 1.0);
        final scale = math.sin(t * math.pi).clamp(0.0, 1.0);
        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: 7, height: 7,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.3 + 0.7 * scale),
            shape: BoxShape.circle,
          ),
        );
      }),
    ),
  );
}

class _FloatingLeaf extends StatelessWidget {
  final int index;
  final Animation<double> rot;
  const _FloatingLeaf({required this.index, required this.rot});

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final offsets = [
      Offset(size.width * 0.08,  size.height * 0.15),
      Offset(size.width * 0.82,  size.height * 0.10),
      Offset(size.width * 0.05,  size.height * 0.65),
      Offset(size.width * 0.88,  size.height * 0.55),
      Offset(size.width * 0.25,  size.height * 0.85),
      Offset(size.width * 0.72,  size.height * 0.80),
    ];
    final sizes     = [18.0, 24.0, 14.0, 22.0, 16.0, 20.0];
    final opacities = [0.12, 0.08, 0.15, 0.10, 0.13, 0.09];
    final speeds    = [1.0,  0.7,  1.3,  0.9,  1.1,  0.8];

    return Positioned(
      left: offsets[index].dx,
      top:  offsets[index].dy,
      child: AnimatedBuilder(
        animation: rot,
        builder: (_, __) => Transform.rotate(
          angle: rot.value * speeds[index],
          child: Icon(Icons.eco_rounded,
              color: _C.accent.withOpacity(opacities[index]),
              size: sizes[index]),
        ),
      ),
    );
  }
}

class _MeshPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;
    paint.color = const Color(0xFF0A3D18);
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paint);
    paint.color = const Color(0xFF1B6B30).withOpacity(0.35);
    const step = 28.0;
    for (double x = 0; x < size.width; x += step) {
      for (double y = 0; y < size.height; y += step) {
        canvas.drawCircle(Offset(x, y), 1.2, paint);
      }
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter _) => false;
}

class _WaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.moveTo(0, size.height * 0.35);
    path.cubicTo(size.width * 0.25, 0, size.width * 0.75,
        size.height * 0.5, size.width, size.height * 0.2);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }
  @override
  bool shouldReclip(_) => false;
}

PageRoute _fadeRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, a, __) => FadeTransition(opacity: a, child: page),
  transitionDuration: const Duration(milliseconds: 600),
);